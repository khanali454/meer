document.getElementById("_select_shower").addEventListener("click",()=>{
    var h = document.getElementById("_more_selects").style.height;
    if(h=="0px"){
        document.getElementById("_more_selects").style.height="fit-content";
    }else{
        document.getElementById("_more_selects").style.height=0;
    }
});